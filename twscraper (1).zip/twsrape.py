from tkinter import *
from ntscraper import Nitter
import json

window=Tk()
title = StringVar()
#window.geometry("{}x{}+0+0".format(window.winfo_screenwidth(), window.winfo_screenheight()))
window.geometry("280x100")
window.configure(bg="grey")
window.iconbitmap("image\logo.ico")
window.title("tweeter scraper")


#labels
l1=Label(window,text="Enter Twitter ID:",padx=4,fg="black",bg="grey")
l1.grid(row=0,column=0,padx=0, pady=40)

#for user entry
e1=Entry(window)
e1.grid(row=0,column=1,padx=0)

#loading label
'''l2=Label(window,text="Loading Data...",font=('Helvetica', 8),fg="#FFBD09")
l2.grid(row=1, column=1,padx=0)'''


b1=Button(window, text="get data",bg="green",command=lambda:get_data(e1.get()))
b1.grid(row=0,column=2, padx=4)

#b2=Button(window, text="Cancel", command=exit)
#b2.grid(row=0,column=3,padx=2)





"""frame1.pack(side=LEFT,anchor="nw")
frame1.grid(row=0,column=0,sticky='w',padx=2, pady=1)



#frame2.grid(row=0,column=0,sticky='nw',padx=20, pady=200)



l=Label(frame1,text="Enter username:",font=('Helvetica', 12),background="white")
textbox=Entry(frame1, font=('Helvetica',10))
b=Button(frame1, text="Get Data!", command=lambda : get_data(textbox.get()), background = "green",padx=8)

l2=Label(window,text="Loading Data...",font=('Helvetica', 8),bg="yellow",fg="#FFBD09").place(x=200,y=200)


for i in range(10):
    l3=Label(window,bg="green", width=2, height=1).place(x=(i+20)*10, y=230)"""

"""window.update()
window.play_animation()

l.pack(side=LEFT)
b.pack(side=RIGHT)
textbox.pack(side=RIGHT)"""

def get_data(username):
    try:
        data=Nitter().get_tweets(e1.get(),mode='user',number=20)
        
        with open(e1.get(),"w") as file:
             json.dump(data,file,indent=20) 
        
    except Exception as e:
        l=Label(l1,text=str(e),font=('Helvetica', 16,'bold'),foreground="red")
        l.pack(side=BOTTOM)

    

       

window.mainloop()
"""def play_animation(l2,l3):
    for i in rang(200):
        for j in range(16):

            l4=Label(window,bg="grey",width=2,height=1).place(x=(j+20)*10,y=230)
            sleep(0.06)
            window.update_idletasks()

            l4=Label(window,bg="black",width=2,height=1).place(x=(j+20)*10,y=230)
    else:
        window.destroy()
        exit(E)"""



#uname=input('enter username: ')
#tweets= Nitter().get_tweets(uname,mode='user',number=4)
#with open("username.json","w") as file:
 #   json.dump(tweets,file,indent=4)